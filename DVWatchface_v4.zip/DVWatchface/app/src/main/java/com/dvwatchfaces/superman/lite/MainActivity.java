package com.dvwatchfaces.superman.lite;

import android.Manifest;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ScrollView;
import android.widget.TextView;

/** Запрос разрешения на календарь + диагностика: что видит провайдер. */
public class MainActivity extends Activity {

    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.BLACK);
        tv = new TextView(this);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(13f);
        tv.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = (int) (getResources().getDisplayMetrics().density * 36);
        tv.setPadding(p, p, p, p * 2);
        sv.addView(tv);
        setContentView(sv);
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CALENDAR}, 1);
        }
        refresh();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        HolidayMask.Result r = HolidayMask.compute(this);
        StringBuilder sb = new StringBuilder("Праздники в календаре\n\n");
        sb.append("Доступ к календарю: ").append(r.permission ? "есть" : "НЕТ").append('\n');
        if (r.permission) {
            sb.append("Календарей: ").append(r.calendars).append('\n');
            sb.append("Событий на весь день (неделя): ").append(r.events).append('\n');
            sb.append("Маска: ").append(r.mask).append("  [");
            String[] d = {"Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"};
            for (int k = 0; k < 7; k++) {
                if ((r.mask & (1 << k)) != 0) sb.append(d[k]).append(' ');
            }
            sb.append("]\n");
            if (!r.details.isEmpty()) sb.append('\n').append(r.details);
        } else {
            sb.append("\nРазрешите доступ к календарю в запросе или в настройках приложения.");
        }
        tv.setText(sb.toString());
    }
}
