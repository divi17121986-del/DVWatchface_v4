package com.dvwatchfaces.superman.lite;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;

/**
 * Считает маску недели: бит k (Пн=0 ... Вс=6) = 1, если в этот день есть
 * «праздничное» событие на весь день. Праздничным считается событие, если
 * календарь похож на календарь праздников (holiday / праздник) или название
 * содержит ключевые слова (праздник, выходной, нерабоч, holiday).
 * Суббота и воскресенье циферблат красит сам, их здесь учитывать не нужно.
 */
public final class HolidayMask {

    public static final class Result {
        public int mask;
        public int events;      // сколько событий на весь день попало в неделю
        public int calendars;   // сколько календарей видно
        public boolean permission;
        public String details = "";
    }

    private HolidayMask() {}

    public static Result compute(Context ctx) {
        Result r = new Result();
        r.permission = ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR)
                == PackageManager.PERMISSION_GRANTED;
        if (!r.permission) return r;

        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        LocalDate mon = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        long monEpochDay = mon.toEpochDay();

        long startMs = mon.minusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        long endMs = mon.plusDays(8).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();

        try (Cursor c = ctx.getContentResolver().query(
                CalendarContract.Calendars.CONTENT_URI,
                new String[]{CalendarContract.Calendars.CALENDAR_DISPLAY_NAME},
                null, null, null)) {
            if (c != null) r.calendars = c.getCount();
        } catch (Exception e) {
            r.details += "calendars: " + e + "\n";
        }

        Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b, startMs);
        ContentUris.appendId(b, endMs);
        String[] proj = {
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.ALL_DAY,
                CalendarContract.Instances.CALENDAR_DISPLAY_NAME,
                CalendarContract.Instances.OWNER_ACCOUNT
        };
        try (Cursor c = ctx.getContentResolver().query(b.build(), proj, null, null, null)) {
            if (c == null) return r;
            while (c.moveToNext()) {
                if (c.getInt(3) != 1) continue;                 // только события на весь день
                String title = lower(c.getString(2));
                String cal = lower(c.getString(4));
                String owner = lower(c.getString(5));
                boolean holidayCal = cal.contains("holiday") || cal.contains("праздник")
                        || owner.contains("holiday");
                boolean keyword = title.contains("праздник") || title.contains("выходн")
                        || title.contains("нерабоч") || title.contains("holiday");
                r.events++;
                if (!(holidayCal || keyword)) continue;
                // события на весь день хранятся по UTC: [begin, end) в сутках от эпохи
                long first = Math.floorDiv(c.getLong(0), 86400000L);
                long last = Math.floorDiv(c.getLong(1) - 1, 86400000L);
                for (long d = first; d <= last; d++) {
                    long k = d - monEpochDay;
                    if (k >= 0 && k <= 6) {
                        r.mask |= (1 << (int) k);
                        r.details += c.getString(2) + " (" + (k + 1) + ")\n";
                    }
                }
            }
        } catch (Exception e) {
            r.details += "instances: " + e + "\n";
        }
        if (r.events == 0) wearable(ctx, r, startMs, endMs, monEpochDay);
        return r;
    }

    /** Запасной путь: провайдер Wear (WearableCalendarContract), данные Google Calendar на часах. */
    private static void wearable(Context ctx, Result r, long startMs, long endMs, long monEpochDay) {
        String[] bases = {
                "content://com.google.android.wearable.provider.calendar/instances/when/",
                "content://com.google.android.wearable.provider.calendar/instances/whenbyday/"
        };
        String[] proj = {"begin", "end", "title", "allDay"};
        for (String base : bases) {
            Uri u = Uri.parse(base + startMs + "/" + endMs);
            try (Cursor c = ctx.getContentResolver().query(u, proj, null, null, null)) {
                if (c == null) { r.details += "wear: null " + base + "\n"; continue; }
                r.details += "wear ok " + base + " rows=" + c.getCount() + "\n";
                while (c.moveToNext()) {
                    String title = lower(c.getString(2));
                    boolean allDay = c.getInt(3) == 1;
                    if (!allDay) continue;
                    r.events++;
                    if (!(title.contains("праздник") || title.contains("выходн")
                            || title.contains("нерабоч") || title.contains("holiday"))) continue;
                    long first = Math.floorDiv(c.getLong(0), 86400000L);
                    long last = Math.floorDiv(c.getLong(1) - 1, 86400000L);
                    for (long d = first; d <= last; d++) {
                        long k = d - monEpochDay;
                        if (k >= 0 && k <= 6) {
                            r.mask |= (1 << (int) k);
                            r.details += "W:" + c.getString(2) + " (" + (k + 1) + ")\n";
                        }
                    }
                }
                if (r.events > 0) return;
            } catch (Exception e) {
                r.details += "wear " + base + ": " + e + "\n";
            }
        }
    }

    private static String lower(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT);
    }
}
